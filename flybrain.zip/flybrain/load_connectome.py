"""Build a real fly-connectome graph from the public Janelia Hemibrain export.

Data source: abejeyapratap/fly-connectome (graph analysis of the Drosophila
Hemibrain connectome as released by Google Research / Janelia FlyEM).

Neurons here: 5596 real neurons, ~1.67M synapses, including 334 visual
projection neurons (LC / LPLC "eye" cells) and 22 descending motor neurons
(DNp) -- a genuine visual->premotor->motor pathway.
"""
import os
import numpy as np
import pandas as pd
from scipy import sparse

DATA = os.path.join(os.path.dirname(__file__), "data")


class Connectome:
    def __init__(self, df):
        ids = np.unique(np.concatenate([df["bodyId_pre"].values,
                                        df["bodyId_post"].values]))
        self.ids = ids
        self.ix = {int(v): i for i, v in enumerate(ids)}
        self.N = len(ids)

        self.pre = np.array([self.ix[x] for x in df["bodyId_pre"]], dtype=np.int32)
        self.post = np.array([self.ix[x] for x in df["bodyId_post"]], dtype=np.int32)
        self.w = df["weight"].values.astype(np.float32)
        self.type_pre = df["type_pre"].astype(str).values
        self.type_post = df["type_post"].astype(str).values

        self.input_ix = np.array([self.ix[x] for x in df.loc[
            df["type_pre"].astype(str).str.startswith("LC"), "bodyId_pre"].unique()])
        self.output_ix = np.array([self.ix[x] for x in df.loc[
            df["type_post"].astype(str).str.startswith("DNp"), "bodyId_post"].unique()])

        nodes = set(range(self.N))
        comp = self._fly_component()
        keep = {n for n in comp} | set(self.input_ix.tolist()) | set(self.output_ix.tolist())
        self.mask = np.array([n in keep for n in range(self.N)], dtype=bool)
        self.compute_matrices()

    def _fly_component(self):
        """Weakly-connected component containing the eye cells and motor cells."""
        adj = {}
        a = self.pre
        b = self.post
        for i in range(len(self.pre)):
            adj.setdefault(int(a[i]), set()).add(int(b[i]))
            adj.setdefault(int(b[i]), set()).add(int(a[i]))
        start = {int(self.input_ix[0]), int(self.output_ix[0])}
        seen = set(start)
        stack = list(start)
        while stack:
            n = stack.pop()
            for m in adj.get(n, ()):
                if m not in seen:
                    seen.add(m)
                    stack.append(m)
        return seen

    def compute_matrices(self):
        keep = self.mask
        remap = {int(n): i for i, n in enumerate(np.where(keep)[0])}
        self.R = int(keep.sum())
        pris = self.pre[keep[self.pre]]
        pris = np.stack([pris, self.post[keep[self.post]]], axis=1)
        pris = [(remap[int(a)], remap[int(b)]) for a, b in pris if int(a) != int(b)]
        pris_set = sorted(set(pris))
        self.edge_pre = np.array([a for a, b in pris_set], dtype=np.int32)
        self.edge_post = np.array([b for a, b in pris_set], dtype=np.int32)
        wsum = {}
        for (a, b) in pris:
            wsum.setdefault((a, b), 0.0)
        # re-derive weights without double-count (use wsum on raw edges)
        wsum = {}
        for i in range(len(self.pre)):
            a, b = int(self.pre[i]), int(self.post[i])
            if a == b or not (keep[a] and keep[b]):
                continue
            key = (remap[a], remap[b])
            wsum[key] = wsum.get(key, 0.0) + float(self.w[i])
        keys = list(wsum.keys())
        self.edge_pre = np.array([k[0] for k in keys], dtype=np.int32)
        self.edge_post = np.array([k[1] for k in keys], dtype=np.int32)
        self.edge_w = np.array([wsum[k] for k in keys], dtype=np.float32)

        rows, cols = self.edge_pre, self.edge_post
        self.mat = sparse.csr_matrix((self.edge_w, (rows, cols)),
                                     shape=(self.R, self.R), dtype=np.float32)

        self.in_ix = np.array(sorted({int(x) for x in self.input_ix if keep[x]}))
        pre = np.array([remap[int(x)] for x in self.input_ix if keep[x]])
        self.out_ix = np.array(sorted({int(x) for x in self.output_ix if keep[x]}))
        post = np.array([remap[int(x)] for x in self.output_ix if keep[x]])
        self.in_ix = pre
        self.out_ix = post

        # plastic synapses: every real synapse that lands on a motor (DNp) neuron
        ep, eo, ew = self.edge_pre, self.edge_post, self.edge_w
        psel = np.isin(eo, self.out_ix)
        self.plast_pre = ep[psel]
        self.plast_post = eo[psel]
        self.plast_w = ew[psel].copy()
        self.plast_id = np.where(psel)[0]

        # non-plastic part of the matrix (remove plastic rows from mat)
        base = self.mat.tolil(copy=True)
        for i, e in enumerate(self.edge_pre[psel]):
            pass  # handled below via rows
        mask = ~psel
        keep_ep, keep_eo, keep_ew = ep[mask], eo[mask], ew[mask]
        self.static_mat = sparse.csr_matrix((keep_ew, (keep_ep, keep_eo)),
                                            shape=(self.R, self.R), dtype=np.float32)


def load():
    path = os.path.join(DATA, "all_connection_df.csv")
    df = pd.read_csv(path)
    return Connectome(df)


if __name__ == "__main__":
    c = load()
    print("neurons kept:", c.R, "/", c.N)
    print("edges:", len(c.edge_w), "synapses:", int(c.edge_w.sum()))
    print("eye (LC) input neurons:", len(c.in_ix))
    print("motor (DNp) output neurons:", len(c.out_ix))
    print("plastic synapses into motor pool:", len(c.plast_w))
    print("static edges:", c.static_mat.nnz)
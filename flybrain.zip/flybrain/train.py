"""Train the fly brain to move chess pieces. No backprop through the brain:
   - real 3-factor reward-modulated plasticity on real connectome synapses
   - policy-gradient on a tiny motor-command readout matrix (64x22 floats).
"""
import argparse
import os
import time
import numpy as np
import chess

from brain import (FlyBrain, FlyBrainPlayer, advisor_move,
                   heuristic_reward, encode_board, material)
from load_connectome import load

LOGEPS = 1e-9
GAMMA = 0.92
LR_MOVE = 0.05


def play_and_train(brain, players, rng, temperature, opp_level):
    """One game vs advisor. Returns result from fly's point of view."""
    fly_color = chess.WHITE if rng.random() < 0.5 else chess.BLACK
    me = players[fly_color]
    board = chess.Board()
    hist = []           # (player, move, act, prob-vec over legal, r, coact, legal)
    rng_adv = np.random.default_rng(rng.integers(0, 2**31))
    result = None

    for ply in range(120):
        side = board.turn
        if side == fly_color:
            legal = list(board.legal_moves)
            feat = encode_board(board, me.ours_is_white)
            act, coact = brain.move_impl(feat)
            scores = np.array([me.D[m.to_square, :] @ act for m in legal])
            scores = scores - scores.max()
            p = np.exp(scores / temperature)
            p = p / (p.sum() + LOGEPS)
            i = int(rng.choice(len(legal), p=p))
            move = legal[i]
            before = board.copy()
            board.push(move)
            r = heuristic_reward(before, move, board, fly_color) - 0.02
            hist.append([me, move, act, p.copy(), r, coact, legal])
            if board.is_checkmate():
                result = 1.0 if fly_color == chess.WHITE else 0.0
                break
        else:
            board.push(advisor_move(board, rng_adv, level=opp_level))
            if board.is_checkmate():
                result = 0.0 if fly_color == chess.WHITE else 1.0
                break
        if board.is_stalemate() or board.is_insufficient_material() or \
           board.is_fifty_moves() or board.is_repetition(3):
            result = 0.5
            break
    if result is None:
        # capped: award by material difference (captures count)
        dm = material(board, fly_color)
        result = 1.0 if dm > 3 else (0.0 if dm < -3 else 0.5)

    fly_result = result if fly_color == chess.WHITE else (1.0 - result)
    term_r = {1.0: 3.0, 0.5: 0.1, 0.0: -3.0}[fly_result]

    n = len(hist)
    # discounted future return G_t for every fly move (incl. per-move rewards)
    G = 0.0
    for k in range(n - 1, -1, -1):
        me_, move, act, p, r, coact, legal = hist[k]
        age = GAMMA ** (n - 1 - k)
        G = r + GAMMA * G
        brain.update_synapses(coact, G)               # real-brain rewiring
        credit = LR_MOVE * G                          # policy-gradient credit
        me_.D[move.to_square, :] += credit * act
        for a, mv in enumerate(legal):
            me_.D[mv.to_square, :] -= credit * p[a] * act
    return fly_result, n


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--games", type=int, default=600)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--save", default="checkpoint.npz")
    ap.add_argument("--eval-every", type=int, default=30)
    args = ap.parse_args()

    HERE = os.path.dirname(os.path.abspath(__file__))
    rng = np.random.default_rng(args.seed)
    conn = load()
    brain = FlyBrain(conn, seed=args.seed)
    players = {chess.WHITE: FlyBrainPlayer(brain, chess.WHITE),
               chess.BLACK: FlyBrainPlayer(brain, chess.BLACK)}

    wins = losses = draws = 0
    roll = []
    t0 = time.time()
    for g in range(1, args.games + 1):
        temperature = max(0.35, 2.0 - 1.8 * (g / args.games))
        opp_level = 0 if g < 0.6 * args.games else 1
        res, nply = play_and_train(brain, players, rng, temperature, opp_level)
        roll.append(res)
        if len(roll) > 300:
            roll.pop(0)
        wins += (res == 1.0)
        losses += (res == 0.0)
        draws += (res == 0.5)
        if g % args.eval_every == 0:
            print(f"[{time.time()-t0:6.1f}s] g={g:4d}/{args.games} "
                  f"temp={temperature:.2f} oppL={opp_level} "
                  f"win%={100*wins/g:5.1f} last300={np.mean(roll):.3f} "
                  f"W{wins} L{losses} D{draws}", flush=True)
        if g % (args.games // 4) == 0 and args.save:
            path = os.path.join(HERE, args.save)
            blk = {d: (b[0], b[1], b[2]) for d, b in brain.blk.items()}
            np.savez(path, D_W=players[chess.WHITE].D, D_B=players[chess.BLACK].D,
                     blk=blk)
            print(f"  saved {path}", flush=True)
    print(f"\nFINAL: W={wins} L={losses} D={draws} win%={100*wins/args.games:.1f}")
    if args.save:
        path = os.path.join(HERE, args.save)
        blk = {d: (b[0], b[1], b[2]) for d, b in brain.blk.items()}
        np.savez(path, D_W=players[chess.WHITE].D, D_B=players[chess.BLACK].D,
                 blk=blk)
        print("saved", path)
    return brain, players


if __name__ == "__main__":
    main()
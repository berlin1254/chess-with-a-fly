"""Evaluate the trained fly brain: greedy (argmax) decode vs advisors.
Usage: python eval.py [checkpoint.npz] [--games N] [--op L]
"""
import argparse
import numpy as np
import chess

from brain import (FlyBrain, FlyBrainPlayer, advisor_move, encode_board, material)
from load_connectome import load


def load_checkpoint(path):
    conn = load()
    brain = FlyBrain(conn, seed=0)
    data = np.load(path, allow_pickle=True)
    blk = data["blk"].item()
    for d, (pre, post, w) in blk.items():
        arr = brain.blk[d]
        arr[0][:] = pre
        arr[1][:] = post
        arr[2][:] = w
    players = {chess.WHITE: FlyBrainPlayer(brain, chess.WHITE),
               chess.BLACK: FlyBrainPlayer(brain, chess.BLACK)}
    players[chess.WHITE].D = data["D_W"]
    players[chess.BLACK].D = data["D_B"]
    return brain, players


def play_games(brain, players, n=80, opp_level=1, rng=None, temp=0.6):
    rng = rng or np.random.default_rng(0)
    wins = losses = draws = 0
    mat = 0.0
    for _ in range(n):
        fc = chess.WHITE if rng.random() < 0.5 else chess.BLACK
        me = players[fc]
        b = chess.Board()
        rg = np.random.default_rng(rng.integers(0, 2**31))
        result = None
        for ply in range(120):
            if b.turn == fc:
                legal = list(b.legal_moves)
                act, _ = brain.move_impl(encode_board(b, me.ours_is_white))
                sc = np.array([me.D[m.to_square, :] @ act for m in legal])
                sc = sc - sc.max()
                pr = np.exp(sc / temp)
                pr = pr / (pr.sum() + 1e-9)
                b.push(legal[int(rng.choice(len(legal), p=pr))])
                if b.is_checkmate():
                    result = 1.0 if fc == chess.WHITE else 0.0
                    break
            else:
                b.push(advisor_move(b, rg, level=opp_level))
                if b.is_checkmate():
                    result = 0.0 if fc == chess.WHITE else 1.0
                    break
            if b.is_stalemate() or b.is_insufficient_material() or \
               b.is_fifty_moves() or b.is_repetition(3):
                result = 0.5
                break
        if result is None:
            dm = material(b, fc)
            result = 1.0 if dm > 3 else (0.0 if dm < -3 else 0.5)
        fr = result if fc == chess.WHITE else (1.0 - result)
        mat += material(b, fc)
        wins += (fr == 1.0)
        losses += (fr == 0.0)
        draws += (fr == 0.5)
    return wins, losses, draws, mat / n


def snapshot_untrained():
    conn = load()
    brain = FlyBrain(conn, seed=0)
    players = {chess.WHITE: FlyBrainPlayer(brain, chess.WHITE),
               chess.BLACK: FlyBrainPlayer(brain, chess.BLACK)}
    return brain, players


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("ckpt", nargs="?", default=None)
    ap.add_argument("--games", type=int, default=120)
    ap.add_argument("--op", type=int, default=0)
    ap.add_argument("--temp", type=float, default=0.6)
    args = ap.parse_args()

    rng = np.random.default_rng(42)
    if args.ckpt:
        brain, players = load_checkpoint(args.ckpt)
        tag = args.ckpt
    else:
        brain, players = snapshot_untrained()
        tag = "UNTRAINED"
    for op in (0, 1):
        w, l, d_, m = play_games(brain, players, n=args.games, opp_level=op,
                                 rng=rng, temp=args.temp)
        print(f"{tag:20s} oppL={op}: W{w} L{l} D{d_}  win%={100*w/args.games:5.1f} "
              f"avgMat(us)={m:+.2f}")
"""Play a visible game: the trained fly brain vs the advisor bot.
Prints SAN moves, final board, and a takeaway.
"""
import argparse
import numpy as np
import chess

from eval import load_checkpoint, snapshot_untrained
from brain import advisor_move, encode_board
from load_connectome import load

PIECE_GLYPH = {None: '.', 1: 'p', 2: 'n', 3: 'b', 4: 'r', 5: 'q', 6: 'k'}


def board_picture(board):
    rows = []
    for r in range(7, -1, -1):
        line = []
        for c in range(8):
            p = board.piece_at(r * 8 + c)
            if p is None:
                line.append('.' if (r + c) % 2 == 0 else ':')
            else:
                ch = PIECE_GLYPH[p.piece_type]
                line.append(ch.upper() if p.color == chess.WHITE else ch)
        rows.append(' '.join(line))
    return '\n'.join(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("ckpt", nargs="?", default="ckpt.npz")
    ap.add_argument("--temp", type=float, default=0.9)
    args = ap.parse_args()

    try:
        brain, players = load_checkpoint(args.ckpt)
        tag = f"trained ({args.ckpt})"
    except Exception:
        brain, players = snapshot_untrained()
        tag = "untrained brain (run train.py first for ckpt.npz)"

    rng = np.random.default_rng(3)
    fly_color = chess.WHITE if rng.random() < 0.5 else chess.BLACK
    me = players[fly_color]
    opp = players[chess.BLACK if fly_color == chess.WHITE else chess.WHITE]
    b = chess.Board()
    rg = np.random.default_rng(9)
    moves = []
    print(f"--- fly brain [{tag}] plays {'WHITE' if fly_color==chess.WHITE else 'BLACK'} vs advisor ---\n")
    for ply in range(120):
        if b.turn == fly_color:
            legal = list(b.legal_moves)
            act, _ = brain.move_impl(encode_board(b, me.ours_is_white))
            sc = np.array([me.D[m.to_square, :] @ act for m in legal])
            sc = sc - sc.max()
            pr = np.exp(sc / args.temp)
            pr = pr / (pr.sum() + 1e-9)
            mv = legal[int(rng.choice(len(legal), p=pr))]
        else:
            mv = advisor_move(b, rg, level=1)
        moves.append(b.san(mv))
        b.push(mv)
        print(f"{ply//2+1:3d}. {moves[-1]:6s}", end='\n' if (ply % 2 == 1 or ply == 0) else '')
        if b.is_game_over():
            break

    print("\n")
    print(board_picture(b))
    print("\nresult:", end=' ')
    if b.is_checkmate():
        print("CHECKMATE -", "fly brain" if b.turn != fly_color else "advisor",
              "wins")
    elif b.is_game_over():
        print("draw")
    else:
        from brain import material
        dm = material(b, fly_color)
        print(f"game continues (capped); fly material edge = {dm:+d}")
    print(f"\nmoves: {', '.join(moves)}")


if __name__ == "__main__":
    main()
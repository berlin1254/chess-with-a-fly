"""GUI chessboard for the fly-brain player.

Two modes:
  - You vs Fly  : you click moves, the trained fly brain answers.
  - Fly vs Bot  : sit back and watch the fly brain duel the advisor.

Requires tkinter (python3-tk). Run from this directory.
"""
import argparse
import os
import threading
import time
import tkinter as tk
import numpy as np
import chess

from brain import advisor_move, encode_board

HERE = os.path.dirname(os.path.abspath(__file__))
LIGHT = "#f0d9b5"
DARK = "#b58863"
SEL = "#f7f769"
MOVE = "#aaffaa"
LAST = "#88d4ff"

GLYPH = {
    (chess.WHITE, chess.PAWN): "\u2659", (chess.WHITE, chess.KNIGHT): "\u2658",
    (chess.WHITE, chess.BISHOP): "\u2657", (chess.WHITE, chess.ROOK): "\u2656",
    (chess.WHITE, chess.QUEEN): "\u2655", (chess.WHITE, chess.KING): "\u2654",
    (chess.BLACK, chess.PAWN): "\u265F", (chess.BLACK, chess.KNIGHT): "\u265F",
    (chess.BLACK, chess.KNIGHT): "\u265E", (chess.BLACK, chess.BISHOP): "\u265D",
    (chess.BLACK, chess.ROOK): "\u265C", (chess.BLACK, chess.QUEEN): "\u265B",
    (chess.BLACK, chess.KING): "\u265A",
}


def load_brain(args):
    ckpt = args.checkpoint or os.path.join(HERE, "ckpt.npz")
    from load_connectome import load
    from brain import FlyBrain, FlyBrainPlayer
    conn = load()
    if os.path.exists(ckpt) and args.use_checkpoint:
        from eval import load_checkpoint
        brain, players = load_checkpoint(ckpt)
    else:
        brain = FlyBrain(conn, seed=0)
        players = {chess.WHITE: FlyBrainPlayer(brain, chess.WHITE),
                   chess.BLACK: FlyBrainPlayer(brain, chess.BLACK)}
    return brain, players


class FlyChessGUI:
    SQ = 66
    def __init__(self, root, brain, players, args):
        self.root = root
        self.brain = brain
        self.players = players
        self.args = args
        self.board = chess.Board()
        self.selected = None
        self.mode = tk.StringVar(value="You vs Fly")
        self.temp = tk.DoubleVar(value=0.9)
        self.thinking = tk.BooleanVar(value=False)
        self.act_trace = []
        self.lastmove = None

        root.title("Fly Brain Chess  -  Drosophila Melanogaster Playground")
        self.cv = tk.Canvas(root, width=self.SQ * 8, height=self.SQ * 8,
                            bg=DARK, highlightthickness=0)
        self.cv.grid(row=0, column=0, rowspan=8)
        self.cv.bind("<Button-1>", self.on_click)

        self.movelist = tk.Listbox(root, width=28, height=20, font=("monospace", 11))
        self.movelist.grid(row=0, column=1, columnspan=2, rowspan=8, sticky="nsew")

        tk.Button(root, text="New Game", command=self.restart).grid(row=8, column=0, sticky="ew")
        tk.Radiobutton(root, text="You vs Fly", variable=self.mode, value="You vs Fly",
                       command=self.restart).grid(row=8, column=1, sticky="ew")
        tk.Radiobutton(root, text="Fly vs Bot", variable=self.mode, value="Fly vs Bot",
                       command=self.restart).grid(row=8, column=2, sticky="ew")
        tk.Label(root, text="brain temp:").grid(row=9, column=0, sticky="w")
        tk.Scale(root, from_=0.05, to=2.5, resolution=0.05, variable=self.temp,
                 orient="horizontal").grid(row=9, column=1, columnspan=2, sticky="ew")
        self.status = tk.Label(root, text="", anchor="w", font=("sans", 10))
        self.status.grid(row=10, column=0, columnspan=3, sticky="ew")

        self.motorbar = tk.Canvas(root, width=self.SQ * 8, height=30, bg="#222")
        self.motorbar.grid(row=11, column=0, columnspan=3, sticky="ew")
        self.actn = 0
        self.restart()

    # ---------- board ----------
    def restart(self):
        self.board = chess.Board()
        self.selected = None
        self.lastmove = None
        self.movelist.delete(0, "end")
        self.draw_motor(np.zeros(len(self.brain.out_ix)))
        self.redraw()
        self.root.after(120, self.step)

    def redraw(self):
        self.cv.delete("all")
        for r in range(8):
            for c in range(8):
                sq = r * 8 + c
                x0, y0 = c * self.SQ, (7 - r) * self.SQ
                fill = LIGHT if (r + c) % 2 == 0 else DARK
                self.cv.create_rectangle(x0, y0, x0 + self.SQ, y0 + self.SQ,
                                         fill=fill, outline="")
        if self.lastmove:
            for sq in (self.lastmove.from_square, self.lastmove.to_square):
                r, c = sq // 8, sq % 8
                x0, y0 = c * self.SQ, (7 - r) * self.SQ
                self.cv.create_rectangle(x0, y0, x0 + self.SQ, y0 + self.SQ,
                                         fill=LAST, outline="", stipple="gray50")
        if self.selected is not None:
            r, c = self.selected // 8, self.selected % 8
            x0, y0 = c * self.SQ, (7 - r) * self.SQ
            self.cv.create_rectangle(x0, y0, x0 + self.SQ, y0 + self.SQ,
                                     fill=SEL, outline="")
        for sq in getattr(self, "hints", []):
            r, c = sq // 8, sq % 8
            x0, y0 = c * self.SQ + 4, (7 - r) * self.SQ + 4
            self.cv.create_oval(x0, y0, x0 + self.SQ - 8, y0 + self.SQ - 8,
                                fill=MOVE, outline="")
        for sq in range(64):
            p = self.board.piece_at(sq)
            if p:
                ch = GLYPH.get((p.color, p.piece_type))
                r, c = sq // 8, sq % 8
                x, y = c * self.SQ + self.SQ // 2, (7 - r) * self.SQ + self.SQ // 2
                self.cv.create_text(x, y, text=ch, font=("DejaVu Sans", 34),
                                    fill="#000")
        self.status.config(text=self.state_text())

    def state_text(self):
        s = self.board
        if s.is_checkmate():
            out = "Checkmate - " + ("Black" if s.turn == chess.WHITE else "White") + " wins"
        elif s.is_stalemate():
            out = "Stalemate"
        elif s.is_insufficient_material():
            out = "Draw (insufficient material)"
        elif s.is_fifty_moves():
            out = "Draw (50-move)"
        elif s.is_repetition(3):
            out = "Draw (3-fold)"
        else:
            out = ("White to move" if s.turn == chess.WHITE else "Black to move")
            if s.is_check():
                out += " - CHECK"
        mode = self.mode.get()
        pos = "you" if (mode == "You vs Fly") else "fly"
        who = "White" if s.turn == chess.WHITE else "Black"
        if mode == "You vs Fly":
            you = "White" if not hasattr(self, "flycolor") else (
                "Black" if self.flycolor == chess.WHITE else "White")
            turn = "YOUR move" if (s.turn == 0) == (you == "White") else "fly brain thinking..."
        else:
            turn = "fly" if (s.turn == self.flycolor) else "advisor"
        return f"{out}  |  {who}  |  {turn}"

    # ---------- interaction ----------
    def on_click(self, ev):
        if self.board.is_game_over():
            return
        mode = self.mode.get()
        if mode == "Fly vs Bot":
            return
        you_white = (not hasattr(self, "flycolor")) or self.flycolor != chess.WHITE
        if self.board.turn != (chess.WHITE if you_white else chess.BLACK):
            return
        c, r = ev.x // self.SQ, 7 - ev.y // self.SQ
        if not (0 <= r < 8 and 0 <= c < 8):
            return
        sq = r * 8 + c
        if self.selected is None:
            p = self.board.piece_at(sq)
            if p and ((p.color == chess.WHITE) == you_white):
                self.selected = sq
                self.hints = [m.to_square for m in self.board.legal_moves
                              if m.from_square == sq]
                self.redraw()
            return
        # second click: try move
        move = None
        for m in self.board.legal_moves:
            if m.from_square == self.selected and m.to_square == sq:
                move = m
                break
        self.selected = None
        self.hints = []
        if move is None:
            self.redraw()
            return
        if move.promotion:
            pt = self.promotion_dialog()
            if not pt:
                self.redraw()
                return
            move = chess.Move(move.from_square, move.to_square, promotion=pt)
        self.play(move)

    def promotion_dialog(self):
        win = tk.Toplevel(self.root)
        win.title("Promote to")
        choice = []
        for i, pt in enumerate((chess.QUEEN, chess.ROOK, chess.BISHOP, chess.KNIGHT)):
            tk.Button(win, text=GLYPH[(self.board.turn, pt)],
                      font=("DejaVu Sans", 26),
                      command=lambda pp=pt: self._set_promo(win, choice, pp)
                      ).grid(row=0, column=i, padx=4, pady=4)
        self.root.wait_window(win)
        return choice[0] if choice else None

    def _set_promo(self, win, choice, pt):
        choice.append(pt)
        win.destroy()

    # ---------- game flow ----------
    def play(self, move):
        san = self.board.san(move)
        turn = self.board.turn
        num = self.board.fullmove_number
        self.board.push(move)
        self.lastmove = move
        if turn == chess.WHITE:
            self.movelist.insert("end", f"{num}. {san}")
        else:
            self.movelist.insert("end", "     " + san)
        self.redraw()
        if not self.board.is_game_over():
            self.root.after(60, self.step)

    def step(self):
        if self.board.is_game_over():
            return
        mode = self.mode.get()
        if not hasattr(self, "flycolor"):
            self.flycolor = chess.WHITE   # the fly brain always plays White
        fly_turn = (self.board.turn == self.flycolor)
        if mode == "You vs Fly":
            if fly_turn:
                self.fly_move()          # fly plays White, you play Black
        else:
            self.fly_move() if fly_turn else self.bot_move()

    def fly_move(self):
        me = self.players[self.flycolor]
        self.thinking.set(True)
        try:
            legal = list(self.board.legal_moves)
            feat = encode_board(self.board, me.ours_is_white)
            act, coact = self.brain.move_impl(feat)
            self.draw_motor(act)
            sc = np.array([me.D[m.to_square, :] @ act for m in legal])
            sc = sc - sc.max()
            pr = np.exp(sc / self.temp.get())
            pr = pr / (pr.sum() + 1e-9)
            mv = legal[int(np.random.default_rng(int(time.time() % 1000))
                           .choice(len(legal), p=pr))]
        except Exception as e:
            self.status.config(text=f"brain error: {e}")
            return
        finally:
            self.thinking.set(False)
        self.play(mv)

    def bot_move(self):
        rg = np.random.default_rng(int(time.time() % 12345))
        mv = advisor_move(self.board, rg, level=1)
        self.play(mv)

    # ---------- motor-intent strip ----------
    def draw_motor(self, act):
        n = len(act)
        width = self.SQ * 8
        self.motorbar.delete("all")
        self.motorbar.create_text(6, 15, text="DNp motor intent:", anchor="w",
                                  fill="#ccc", font=("sans", 9))
        w = (width - 130) / n
        for i, a in enumerate(act):
            h = max(2, int(a * 26))
            x = 130 + i * w
            self.motorbar.create_rectangle(x, 30 - h, x + w - 3, 30,
                                           fill="#ff4444" if a > 0.5 else "#44ff66",
                                           outline="")
        self.act = act


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--checkpoint", default=None)
    ap.add_argument("--no-checkpoint", dest="use_checkpoint", action="store_false")
    ap.set_defaults(use_checkpoint=True)
    args = ap.parse_args()

    try:
        brain, players = load_brain(args)
    except Exception as e:
        print("could not load brain:", e)
        return 1

    root = tk.Tk()
    g = FlyChessGUI(root, brain, players, args)
    root.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
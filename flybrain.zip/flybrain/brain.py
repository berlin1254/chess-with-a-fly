"""The fly-brain chess player.

Drives chess from the REAL Janelia Hemibrain connectome
(5596 neurons, 1.67M synapses).

How it maps to chess:
  - 334 real LC optic-lobe neurons      -> the "eye" that sees the chessboard
  - the real downstream network (1689 + 2000+ neurons along real synapses)
                                        -> the brain that digests the picture
  - 22 real DNp descending motor neurons-> the "motor pool" that emits intent
  - ALL synapses used here are REAL connectome synapses, extracted as a
    feedforward cascade by following actual axons (BFS in synapse space).
    Cyclic recurrence is dropped so the picture actually flows through.

Learning (no backprop through the brain):
  - 3-factor reward-modulated plasticity rewires the real synapses
    (fly-style: winner = potentiate recently-active synapses, loser = depress).
  - a tiny 64x22 motor-command matrix M maps motor intent -> destination
    square, trained by policy gradient (1408 floats, the "muscle map").
"""
import os
import numpy as np
import chess
from collections import deque

from load_connectome import load

PIECE_VAL = {chess.PAWN: 1, chess.KNIGHT: 3, chess.BISHOP: 3,
             chess.ROOK: 5, chess.QUEEN: 9, chess.KING: 0}
N_ENC = 69


def encode_board(board, ours_is_white, feat_scale=4.0):
    f = np.zeros(N_ENC, dtype=np.float32)
    for sq in range(64):
        p = board.piece_at(sq)
        if p:
            friend = p.color == (chess.WHITE if ours_is_white else chess.BLACK)
            v = PIECE_VAL[p.piece_type] / 10.0
            f[sq] = (v if friend else -v) * feat_scale
    f[64] = 1.0 if ours_is_white else -1.0
    f[65] = material(board, ours_is_white) / 40.0
    f[66] = 1.0 if board.is_check() else 0.0
    f[67] = 1.0 if board.has_castling_rights(ours_is_white) else 0.0
    f[68] = 0.5
    return f


def material(board, ours_is_white):
    s = 0
    for sq in range(64):
        p = board.piece_at(sq)
        if p and p.piece_type != chess.KING:
            v = PIECE_VAL[p.piece_type]
            s += v if (p.color == (chess.WHITE if ours_is_white else chess.BLACK)) else -v
    return s


def build_layers(conn, maxw=2000):
    """BFS from the eye cells along real synapses -> depth. Motor cells must stay."""
    pre, post = conn.edge_pre, conn.edge_post
    adj = {}
    for a, b in zip(pre, post):
        adj.setdefault(int(a), []).append(int(b))
    in_w = {}
    for a, b, ww in zip(pre, post, conn.edge_w):
        in_w[int(b)] = in_w.get(int(b), 0.0) + ww

    eye = set(conn.in_ix.tolist())
    motor = set(conn.out_ix.tolist())
    depth = {int(n): -1 for n in range(conn.R)}
    dq = deque()
    for e in eye:
        depth[e] = 0
        dq.append(e)
    while dq:
        n = dq.popleft()
        for m in adj.get(n, ()):
            if depth[m] < 0:
                depth[m] = depth[n] + 1
                dq.append(m)
    layers = {}
    for n, d in depth.items():
        if d >= 0:
            layers.setdefault(d, []).append(n)
    maxd = max(depth[int(m)] for m in motor if depth[int(m)] > 0)

    kept = {0: list(eye)}
    for d in range(1, maxd + 1):
        nodes = list(layers.get(d, []))
        motors_here = [n for n in nodes if n in motor]
        if len(nodes) > maxw:
            nodes = sorted(nodes, key=lambda n: in_w.get(int(n), 0), reverse=True)[:maxw]
            nodes = list(set(nodes) | set(motors_here))
        kept[d] = nodes
    node_set = set(x for v in kept.values() for x in v)

    edges = {}
    for a, b, ww in zip(pre, post, conn.edge_w):
        a, b = int(a), int(b)
        da, db = depth.get(int(a), -1), depth.get(int(b), -1)
        if a in node_set and b in node_set and 0 <= da and db > da:
            key = (a, b)
            edges[key] = edges.get(key, 0.0) + ww
    return kept, depth, edges, motor


class FlyBrain:
    def __init__(self, conn, seed=0, beta=4.0, passes=2, noise=0.04,
                 in_gain=4.0, lr3=0.03, maxw=2000):
        self.rng = np.random.default_rng(seed)
        self.R = conn.R
        kept, depth, edges, motor = build_layers(conn, maxw=maxw)
        self.layers = [np.array(sorted(nodes), dtype=np.int64)
                       for nodes in kept.values()]
        self.depth = depth
        self.motor = sorted(motor)
        self.out_ix = np.array([m for m in self.motor if depth[int(m)] > 0])
        self.in_ix = np.array(kept[0])
        self.beta = beta
        self.passes = passes
        self.noise = noise
        self.in_gain = in_gain
        self.lr3 = lr3

        n_eye = len(kept[0])
        F = np.sign(self.rng.standard_normal((n_eye, N_ENC)))
        F = F * (self.rng.random((n_eye, N_ENC)) < 0.4)
        self.F = F.astype(np.float32)

        # index neurons within their layer
        local = {}
        for d, arr in enumerate(self.layers):
            for i, n in enumerate(arr.tolist()):
                local[int(n)] = (d, i)
        self.motor_local = np.array([local[int(m)] for m in self.out_ix.tolist()])

        # transitions: real edges layer d -> d+1, in local indices
        self.T = []
        self.coact = []
        layer_in = {}
        for (a, b), ww in edges.items():
            da = depth[int(a)]
            db = depth[int(b)]
            if db == da + 1:
                self.coact.append(0.0)
                self.T.append((local[int(a)], local[int(b)], ww))
                layer_in.setdefault(db, []).append(ww)
        norm = {}
        for d, ws in layer_in.items():
            ws = np.array(ws)
            norm[d] = (float(ws.mean()), max(float(ws.std()), 1e-6))
        self.norm = norm
        self.m = np.zeros(len(self.layers), dtype=np.float32)
        self.s = np.ones(len(self.layers), dtype=np.float32)
        for d in norm:
            self.m[d] = norm[d][0]
            self.s[d] = norm[d][1]
        self.d_edges = [d for (d, _), _, _ in self.T]
        # For plasticity we need per-edge layer id; store arrays split by layer
        self._split_transitions()

    def _split_transitions(self):
        """Pre-sort transitions into per-layer block arrays for vector access."""
        per = {}
        for k, (pre, post, w) in enumerate(self.T):
            d = self.d_edges[k]
            per.setdefault(d, {"pre": [], "post": [], "w": []})
            per[d]["pre"].append(pre[0])
            per[d]["post"].append(post[0])
            per[d]["w"].append(w)
        dx = {}
        for d, blk in per.items():
            dx[d] = (np.array(blk["pre"]), np.array(blk["post"]),
                     np.array(blk["w"], dtype=np.float32))
        self.blk = dx
        self.d_layers = sorted(dx.keys())

    def project(self, feat):
        return (self.F @ feat) * self.in_gain

    def _cascade(self, drive, track=True):
        layers = self.layers
        r = {0: drive.astype(np.float64)}
        co = {}
        for d in self.d_layers:
            pre, post, W = self.blk[d]
            rcur = r.get(d)
            nxt = np.zeros(len(layers[d + 1]))
            npre = pre if pre is not None else []
            if rcur is not None and len(npre):
                hits = rcur[npre]
                np.add.at(nxt, post, W * hits)
            m, s = self.m[d + 1], self.s[d + 1]
            y = (nxt - m) / s
            rnext = 1.0 / (1.0 + np.exp(-self.beta * y))
            if track:
                co[d] = rcur[npre] * rnext[post] if (rcur is not None and len(npre)) \
                    else np.zeros(len(pre))
            r[d + 1] = rnext
        out = np.array([r[self.motor_local[i][0]][self.motor_local[i][1]]
                        for i in range(len(self.motor_local))])
        return out, co

    def move_impl(self, feat):
        drive = self.project(feat)
        outs = 0.0
        coact = {d: np.zeros(len(self.blk[d][0])) for d in self.d_layers}
        for p in range(self.passes):
            dr = drive + self.noise * self.rng.standard_normal(drive.shape)
            out, co = self._cascade(dr)
            outs += out
            for d in co:
                coact[d] += co[d]
        out = outs / self.passes
        scale = out.max() if out.max() > 0 else 1.0
        act = out / scale
        return act, coact

    def update_synapses(self, coact, reward):
        """3-factor plasticity: potentiate/depress the real synapses."""
        for d in self.d_layers:
            pre, post, W = self.blk[d]
            co = coact[d]
            dw = self.lr3 * float(reward) * co * self.s[d + 1]
            W[:] += np.clip(dw, -3.0 * self.s[d + 1], 3.0 * self.s[d + 1])
            np.clip(W, 0, None, out=W)


class FlyBrainPlayer:
    def __init__(self, brain, color, seed=1):
        self.brain = brain
        self.color = color
        self.D = np.zeros((64, len(brain.out_ix)), dtype=np.float64)
        self.mom = np.zeros_like(self.D)

    @property
    def ours_is_white(self):
        return self.color == chess.WHITE

    def move(self, board, temperature=1.0, greedy=False):
        legal = list(board.legal_moves)
        feat = encode_board(board, self.ours_is_white)
        act, coact = self.brain.move_impl(feat)
        self.coact = coact
        self.last_act = act
        scores = np.array([self.D[m.to_square, :] @ act for m in legal])
        if greedy:
            i = int(np.argmax(scores))
            return legal[i], act, scores
        scores = scores - scores.max()
        p = np.exp(scores / temperature)
        p = p / p.sum()
        i = int(self.brain.rng.choice(len(legal), p=p))
        return legal[i], act, scores


def advisor_move(board, rng, level=1):
    legal = list(board.legal_moves)
    if level == 0:
        return rng.choice(legal)
    best = []
    best_score = -1e9
    for m in legal:
        s = 0.0
        caught = board.piece_at(m.to_square)
        if caught:
            s += PIECE_VAL[caught.piece_type] * 10
        if m.promotion:
            s += 5
        push = board.copy()
        push.push(m)
        if push.is_check():
            s += 3
        if board.is_en_passant(m) or caught or m.promotion:
            s += 2
        s += rng.standard_normal() * 3
        if s > best_score:
            best_score = s
            best = [m]
        elif s == best_score:
            best.append(m)
    return rng.choice(best) if best else rng.choice(legal)


def heuristic_reward(board_before, move, board_after, fly_color):
    r = (material(board_after, fly_color) - material(board_before, fly_color))
    if board_after.is_check():
        r += 0.3
    if board_after.is_checkmate():
        r += 2.0
    return r